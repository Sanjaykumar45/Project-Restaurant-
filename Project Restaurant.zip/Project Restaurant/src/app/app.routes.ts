import { Routes } from '@angular/router';
import { HomeComponent } from './admin/home/home.component';
import { AboutComponent } from './admin/about/about.component';
import { MenuComponent } from './admin/menu/menu.component';
import { BookingsComponent } from './admin/bookings/bookings.component';
import { ContactComponent } from './admin/contact/contact.component';
import { LoginComponent } from './auth/login/login.component';
import { NavbarComponent } from './admin/navbar/navbar.component';

export const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    {path: 'login', component: LoginComponent},
    {path: 'home',component: HomeComponent},
    {path: 'about', component: AboutComponent},
    {path: 'menu', component: MenuComponent},
    {path: 'booking', component: BookingsComponent},
    {path: 'contact', component: ContactComponent},
    {path: 'navbar', component: NavbarComponent}
];
