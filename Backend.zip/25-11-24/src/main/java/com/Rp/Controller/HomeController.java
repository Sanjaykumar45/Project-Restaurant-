package com.Rp.Controller;

import java.util.List;


import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Rp.entity.BookingData;
import com.Rp.entity.BookingEntry;
import com.Rp.entity.BookingTable;
import com.Rp.entity.ContactUs;
import com.Rp.entity.Dinner;
import com.Rp.entity.Lunch;
import com.Rp.entity.InsBooking;
import com.Rp.entity.LoginRequest;
import com.Rp.entity.LoginResponse;
import com.Rp.entity.SignupRequest;
import com.Rp.entity.SignupResponse;
import com.Rp.service.Userservice;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletRequest;


@RestController
@RequestMapping("/Rp/auth")
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class HomeController {

	
	@Autowired 
	private Userservice service;

	@PostMapping("/login")
	public ResponseEntity<LoginResponse> log(@RequestBody LoginRequest request, HttpServletResponse response) {

		String username = request.getUsername();
		String password = request.getPassword();

		LoginResponse res = service.validateUser(username, password);
		
		if (res.getMessage()!= null || res.getErrMsg()!=null) {
			
			res.setRedirectUrl("/home");
			res.setSuccess(true);
			
			
			if(request.isAllowCookies()) {
				Cookie userCookie = new Cookie("userId", String.valueOf(res.getUserid()));
				userCookie.setSecure(false); 
				userCookie.setPath("/"); 
				userCookie.setMaxAge(60 * 60 * 24); 
				userCookie.setHttpOnly(true);
				response.addCookie(userCookie);
				
				Cookie usernameCookie = new Cookie("username", username);
				usernameCookie.setPath("/");
				usernameCookie.setMaxAge(60 * 60 * 24); 
				usernameCookie.setSecure(false);
				usernameCookie.setHttpOnly(true); 
				response.addCookie(usernameCookie);
	
				System.out.println("userid *** " + userCookie.getValue());
				System.out.println("username *** " + usernameCookie.getValue());
			}
			 
			 if(res.getErrMsg()!=null) {
				 res.setSuccess(false);
				 res.setRedirectUrl(null);
			 }
			
			 return ResponseEntity.ok(res);	
			 
		} else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
					.body(new LoginResponse("Invalid credentials", false, null, 0, 0, null)); // Invalid credentials
		}

	}

	
	@GetMapping("/profile")
    public ResponseEntity<String> getUserProfile(HttpServletRequest request) {
        String userId = getCookieValue(request, "userId");
        String username = getCookieValue(request, "username");

        if (userId != null && username != null) {
            return ResponseEntity.ok("User ID: " + userId + ", Username: " + username);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("No valid session found.");
        }
    }

    private String getCookieValue(HttpServletRequest request, String cookieName) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(cookieName)) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
	
	

    @PostMapping("/signup")
    public ResponseEntity<SignupResponse> signup(@RequestBody SignupRequest request) {
        String username = request.getUsername();
        String email = request.getEmail();
        String password = request.getPassword();
        String confirmPassword = request.getConfirmPassword();
        SignupResponse sr = new SignupResponse();
        
        String isSignupSuccessful = service.validateSignup(username, email, password, confirmPassword);

        	if("The username you entered is already taken. Please choose another one.".equals(isSignupSuccessful) || "The email address is already registered. Please use a different email.".equals(isSignupSuccessful)||"Your passwords do not match. Please ensure both passwords are the same.".equals(isSignupSuccessful)) {
        		sr.setRedirectUrl(null);
        		sr.setSuccess(false);
        		sr.setErrorMessage(isSignupSuccessful);
        		return ResponseEntity.ok(sr);
        	}else {
        		sr.setRedirectUrl("/login");
        		sr.setSuccess(true);
        		sr.setMessage(isSignupSuccessful);
        		return ResponseEntity.ok(sr);    
        } 
    }


    @PostMapping("/booking")
	public ResponseEntity<LoginResponse> bookingEntry(@RequestBody BookingEntry book) {

		String res = service.insertBooking(book);

		if (res != null) {
			LoginResponse lr = new LoginResponse();
			
			if(res.equals("Your booking has been successfully completed. We look forward to serving you!")) {
				    lr.setMessage(res);
				    lr.setErrMsg(null);
					lr.setRedirectUrl("/home");
					lr.setSuccess(true);
					return ResponseEntity.ok(lr);
			}else {
					lr.setMessage(null);
				    lr.setErrMsg(res);
					lr.setRedirectUrl(null);
					lr.setSuccess(false);
					return ResponseEntity.ok(lr);
			}	

		} else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
					.body(new LoginResponse("Invalid credentials", false, null, 0, 0, null)); // Invalid credentials
		}

	}
    
    
    @GetMapping("/showDinnerSlots")
  	public ResponseEntity<Dinner> showTimeSlots() {

  		Dinner res = service.getDinnerTimings();
  		
  		if (res != null) {
  			return ResponseEntity.ok(res);

  		} else {
  			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
  					.body(null); // Invalid credentials
  		}

  	}

	   @GetMapping("/showLunchSlots")
  	public ResponseEntity<Lunch> showLunchTimeSlots() {

  		Lunch res = service.getLunchTimings();
  		
  		if (res != null) {
  			return ResponseEntity.ok(res);

  		} else {
  			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
  					.body(null); // Invalid credentials
  		}

  	}

	 @GetMapping("/showBookingTable")
  	public ResponseEntity<List<BookingEntry>> showBooking() {
    	
    	List<BookingEntry> res = service.getBookingDetails();
  		
  		if (res != null) {
  			return ResponseEntity.ok(res);

  		} else {
  			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
  					.body(null); // Invalid credentials
  		}

  	}
	 
	 @PostMapping("/UpdateBookingtable") //ragul codes
		public ResponseEntity<Void> updateBookingtable(@RequestParam int groupid, @RequestBody BookingEntry Dinetable ) {

			boolean updated = service.updateBookingtable(Dinetable, groupid);

			return updated ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
		}
	 
	 @DeleteMapping("/DeleteBookingtable") 
		public ResponseEntity<String> deleteBookingtable(@RequestParam int bookingId ) {

			String updated = service.deleteBookingtable(bookingId);

			if (updated != null) {
	  			return ResponseEntity.ok(updated);

	  		} else {
	  			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
	  					.body(null); // Invalid credentials
	  		}
		}

    

    @GetMapping("/userTable") //ragul codes
	public ResponseEntity<List<Map<String, Object>>> postMethodName(@RequestParam int groupid) {

		List<Map<String, Object>> table = service.fetchuser(groupid);
		if (table.isEmpty()) {
			return ResponseEntity.noContent().build();
		}

		return ResponseEntity.ok(table);
	}
    
    @PostMapping("/block")
	public ResponseEntity<String> Blockuser(@RequestParam String username,@RequestParam int groupid){
		boolean updated = service.Blockuser(username,groupid);
		
		return updated ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
	}
	
	@PostMapping("/contact")
	public ResponseEntity<String> Contact(@RequestBody ContactUs contact){
		boolean updated = service.Contact(contact);
		
		return updated ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
	}
	
	
	@GetMapping("/showContact")
	public ResponseEntity<List<ContactUs>> getContact(){
		
		List<ContactUs> res = service.showAllContact();
		if (res.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(res);
	
	}



	


}
