import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import emailjs from 'emailjs-com';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent implements OnInit{
  contactForm: any;

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.contactForm = this.fb.group({
      name: [''],
      email: [''],
      phone: [''],
      message: ['']
    });
  }

  onSubmit(){
    // alert("Message sent successfully");
    this.sendEmailVerification();
  }

  sendEmailVerification() {
    const contactDetails = {
      from_name: this.contactForm.value.name,
      email: this.contactForm.value.email,
      phone: this.contactForm.value.phone,
      message: this.contactForm.value.message

    };

    // EmailJS service call
    emailjs.send('service_foodiefriends', 'template_contact', contactDetails, 'krXtgDQ_zhz7qq5mM')
      .then(
        (response) => {
          console.log('SUCCESS!', response);
          alert("Success")
        },
        (error) => {
          console.log('FAILED...', error);
          alert("failed")
        }
      );
  }

}
