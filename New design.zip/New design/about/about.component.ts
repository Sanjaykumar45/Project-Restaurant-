import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import flatpickr from "flatpickr";

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './about.component.html',
  styleUrl: './about.component.css'
})
export class AboutComponent {


 // Reservation object to bind form values
 reservation = {
  username: '',
  email: '',
  phone: '',
  date: '',
  cuisines: {
    indian: false,
    continental: false,
    mexican: false
  },
  guests: '',
  tableType: '',
  indoorType: '',
  eventType: ''
};

// Method to handle table type change and enable/disable fields
onTableTypeChange() {
  if (this.reservation.tableType === 'indoor') {
    this.reservation.indoorType = 'ac'; // Set default value for indoorType
  } else if (this.reservation.tableType === 'events') {
    this.reservation.eventType = 'birthday'; // Set default value for eventType
  }
}
}
