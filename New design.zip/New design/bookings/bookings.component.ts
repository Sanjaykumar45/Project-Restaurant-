import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms'; 
import emailjs from 'emailjs-com';

@Component({
  selector: 'app-bookings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule , FormsModule],
  templateUrl: './bookings.component.html',
  styleUrl: './bookings.component.css'
})
export class BookingsComponent {

  // tableTypeControl = new FormControl('');
  
  // indoor: boolean = false;
  // occassion: boolean = false;

  // constructor() {
  //   // Subscribe to value changes on the FormControl
  //   this.tableTypeControl.valueChanges.subscribe((value:any) => this.onItemClick(value));
  // }

  // onItemClick(item: string) {
  //   if (item === 'indoor') {
  //     this.indoor = true;
  //     this.occassion = false;
  //   } else if (item === 'occassion') {
  //     this.indoor = false;
  //     this.occassion = true;
  //   } else {
  //     this.indoor = false;
  //     this.occassion = false;
  //   }
  // }

  constructor(){
  }

  user = {
    username: '',
    email: '',
    phone: ''
  };

  reservation = {
    date: '',
    cuisine: '',
    mealTime: '',
    tableType: '',
    indoorType: '',
    eventType: '',
    guests: '',
    slotTime: ''
  };

  showConfirmation = false;


  onSubmit() {
    
      this.showConfirmation = true; // Show the confirmation box
  }

  confirmBooking() {
    alert('Booking Confirmed!');
    this.sendEmailVerification();
    // Optionally send this data to the server here
  }

  sendEmailVerification() {
    const bookingDetails = {
      to_name: this.user.username,
      email: this.user.email,
      booking_date: this.reservation.date,
      no_of_guests: this.reservation.guests,
      booking_time: this.reservation.slotTime,
      booking_id: 675432
    };

    // EmailJS service call
    emailjs.send('service_foodiefriends', 'template_booking', bookingDetails, 'krXtgDQ_zhz7qq5mM')
      .then(
        (response) => {
          console.log('SUCCESS!', response);
          alert("Success")
        },
        (error) => {
          console.log('FAILED...', error);
          alert("failed")
        }
      );
  }

 
}