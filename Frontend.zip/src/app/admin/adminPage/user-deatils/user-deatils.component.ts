import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AdminNavbarComponent } from '../admin-navbar/admin-navbar.component';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-deatils',
  standalone: true,
  imports: [RouterModule, CommonModule, AdminNavbarComponent],
  templateUrl: './user-deatils.component.html',
  styleUrl: './user-deatils.component.css'
})
export class UserDeatilsComponent implements OnInit {

  getUser: any;

  constructor(private service: AdminServiceService) { }

  ngOnInit(): void {
    this.getUserDetails();
  }

  getUserDetails() {
    this.service.getUserDetail().subscribe(res => {
      this.getUser = res;

      console.log(res)

    })
  }

  blockUser(username: string) {
    // alert(username)
    Swal.fire({
      title: "Are you sure?",
    html: `You are about to block <strong style="color: red;">${username}!</strong>`,
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, block it!",
    cancelButtonText: 'No, cancel!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.service.blockUserByAdmin(username).subscribe((res) => {
          console.log(res);
        })
        Swal.fire({
          title: "Blocked!",
          html: `<strong style="color: red;">${username}</strong> has been blocked successfully.`,
          icon: "success",
          confirmButtonText: "OK"
        });
        this.getUserDetails();
      }
    });
  }
}


