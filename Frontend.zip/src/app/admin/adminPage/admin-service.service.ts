import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

  constructor(private http: HttpClient) { }

  userDetailApi: string = 'http://localhost:8082/Rp/auth/userTable?groupid=0'

  bookingDetailsApi: string = 'http://localhost:8082/Rp/auth/showBookingTable'

  deleteBookingTable: string = 'http://localhost:8082/Rp/auth/DeleteBookingtable?bookingId='

  blockUserApi: string = 'http://localhost:8082/Rp/auth/block?groupid=0&username='

  queriesApi: string = 'http://localhost:8082/Rp/auth/showContact'

  getUserDetail(): Observable<any>{
    return this.http.get(this.userDetailApi);
  }

  getBookingDetail(): Observable<any>{
    return this.http.get(this.bookingDetailsApi);
  }

  deleteBookingById(bookingId:any){
    return this.http.delete(`${this.deleteBookingTable}${bookingId}`);
  }

  blockUserByAdmin(username:any){
    return this.http.post(`${this.blockUserApi}${username}`,{});
  }

  contactQueries(){
    return this.http.get(this.queriesApi);
  }
}
