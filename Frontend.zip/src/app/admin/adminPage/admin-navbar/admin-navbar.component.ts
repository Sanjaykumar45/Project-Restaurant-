import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-admin-navbar',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './admin-navbar.component.html',
  styleUrl: './admin-navbar.component.css'
})
export class AdminNavbarComponent {

  isLoggedIn: boolean = false;
  getUser: any;
  username: any = '';
  user:any;
  
  constructor(private service: AdminServiceService){}
  
  
  ngOnInit(): void {
  
   this.user=  sessionStorage.getItem('Username');
  
    this.getUserDetails();
  }
  
  
  getUserDetails() {
    this.service.getUserDetail().subscribe(res => {
      // this.getUser = res;
      this.username = res;
  
      
      //const filteredBooks = this.username.filter((val: {username: any}) => val.username.includes(this.user));
      
      //alert(filteredBooks);
      
    })
  }
}
