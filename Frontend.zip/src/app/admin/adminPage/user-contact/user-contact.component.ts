import { Component, OnInit } from '@angular/core';
import { AdminNavbarComponent } from '../admin-navbar/admin-navbar.component';
import { AdminServiceService } from '../admin-service.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-contact',
  standalone: true,
  imports: [AdminNavbarComponent, CommonModule],
  templateUrl: './user-contact.component.html',
  styleUrl: './user-contact.component.css'
})
export class UserContactComponent implements OnInit{

  contact: any;

  constructor(private service: AdminServiceService){}


  ngOnInit(): void {
    this.getUserQueries();
  }

  
  getUserQueries(){
    this.service.contactQueries().subscribe(res=>{
      this.contact = res;
      console.log(res);
    })
  }

}
