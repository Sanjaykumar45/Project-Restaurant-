import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { CommonModule } from '@angular/common';
import { AdminNavbarComponent } from '../admin-navbar/admin-navbar.component';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-booking-details',
  standalone: true,
  imports: [RouterModule, CommonModule, AdminNavbarComponent],
  templateUrl: './booking-details.component.html',
  styleUrl: './booking-details.component.css'
})
export class BookingDetailsComponent implements OnInit {

  getBooking: any;
  bookingId: any;

  constructor(private service: AdminServiceService) { }


  ngOnInit(): void {
    this.getBookingDetails();
  }


  getBookingDetails() {
    this.service.getBookingDetail().subscribe(res => {
      this.getBooking = res;

      console.log(this.getBooking);

    })
  }

  deleteBookingData(bookingId: any) {
    // alert(bookingId)
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: 'No, cancel!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.service.deleteBookingById(bookingId).subscribe((res) => {
          console.log(res);
        })
        Swal.fire({
          title: "Deleted!",
          text: "Data Deleted successfull",
          icon: "success",
          confirmButtonText:"Ok"
        });
        this.getBookingDetails();
      }
    });
  }


}
