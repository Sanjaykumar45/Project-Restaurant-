import { CommonModule } from '@angular/common';
import { Component, HostListener, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { NavbarComponent } from '../navbar/navbar.component';
import emailjs from 'emailjs-com';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-bookings',
  standalone: true,
  imports: [RouterModule, CommonModule, FormsModule, ReactiveFormsModule, NavbarComponent],
  templateUrl: './bookings.component.html',
  styleUrl: './bookings.component.css'
})
export class BookingsComponent implements OnInit {

  indoor: boolean = false;
  indoorType: boolean = false;
  outdoor: boolean = false;
  private: boolean = false;
  events: boolean = false;
  eventsTypes: boolean = false 
  birthday: boolean = false;
  anniversary: boolean = false;
  business: boolean = false;
  reunion: boolean = false;
  lunch: boolean = false;
  mealTime: boolean = true;
  dinner: boolean = false;
  Guests: boolean = true;
  eventsGuests: boolean = false;
  selectedMealTime: string = '';

  lunchSlots: any[] = [];
  lunchIndoor: any;
  lunchOutdoor: any;
  lunchPrivate: any;

  DinnerSlots: any[] = [];
  dinnerIndoor: any;
  dinnerOutdoor: any;
  dinnerPrivate: any;

  tableType: string = '';
  guestOptions: number[] = [];
  eventsType: string = ''

  constructor(private service: UserServiceService) { }


  ngOnInit(): void {
    // emailjs.init("krXtgDQ_zhz7qq5mM");
  }

  bookingForm = new FormGroup({
    username: new FormControl('',[Validators.required,Validators.pattern('^[^\\s].*$')]),
    email: new FormControl('',[Validators.required, Validators.pattern('^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$')]),
    phone: new FormControl('',[Validators.required,Validators.pattern('^\\d{10}$')]),
    date: new FormControl(''),
    cuisines: new FormControl(''),
    noOfGuests: new FormControl(''),
    mealTime: new FormControl(''),
    tableType: new FormControl(''),
    indoorType: new FormControl(''),
    eventsType: new FormControl(''),
  })

  onItemClick(event: Event): void {
    const selectedValue = (event.target as HTMLSelectElement).value;

    this.tableType = (event.target as HTMLSelectElement).value;
    this.eventsType = (event.target as HTMLSelectElement).value;

    if (this.tableType === 'indoor' || this.tableType === 'outdoor' || this.tableType === 'private') {
      this.guestOptions = [2, 3, 4, 5, 6, 7, 8, 9, 10]; 
    } else if (this.tableType === 'events') {
      this.guestOptions = [50, 100]; 
    } else if (this.eventsType === 'birthday' || this.eventsType === 'anniversary' || this.eventsType === 'business' || this.eventsType === 'reunion'){
      this.guestOptions = [50, 100];
    } else {
      this.guestOptions = [];  
    }


    if (selectedValue == 'dinner') {
      this.showDinner();
      this.dinner = true;
      this.lunch = false;
      this.indoor = true;
      this.indoorType = true;
      this.outdoor = true;
      this.private = true;
      this.events = false;
      this.eventsTypes = false;
      this.eventsGuests = false;
      this.Guests = true;
    }

    if (selectedValue == "lunch") {
      this.showLunch();
      this.lunch = true;
      this.dinner = false;
      this.indoor = true;
      this.indoorType = false;
      this.outdoor = true;
      this.private = true;
      this.events = false;
      this.eventsTypes = false;
      this.eventsGuests = false;
      this.Guests = true;
    }

    if (selectedValue == "indoor") {
      this.indoor = true;
      this.indoorType = true;
      this.outdoor = false;
      this.private = false;
      this.events = false;
      this.eventsTypes = false;
      this.mealTime = true;
      this.eventsGuests = false;
      this.Guests = true;
    }

    if (selectedValue == "outdoor") {
      this.indoor = false;
      this.indoorType = false;
      this.outdoor = true;
      this.private = false;
      this.events = false;
      this.eventsTypes = false;
      this.mealTime = true;
      this.eventsGuests = false;
      this.Guests = true;
    }

    if (selectedValue == "private") {
      this.indoor = false;
      this.indoorType = false;
      this.events = false;
      this.eventsTypes = false;
      this.outdoor = false;
      this.private = true;
      this.mealTime = true;
      this.eventsGuests = false;
      this.Guests = true;
    }

    if (selectedValue == "events") {
      this.indoor = false;
      this.indoorType = false;
      this.events = true;
      this.eventsTypes = true;
      this.outdoor = false;
      this.private = false;
      this.mealTime = false;
      this.eventsGuests = true;
      this.Guests = false;
    }

    if (selectedValue == "birthday") {
      this.birthday = true;
      this.anniversary = false;
      this.business = false;
      this.reunion = false;
      this.eventsGuests = true;
      this.Guests = true;
    }

    if (selectedValue == "anniversary") {
      this.birthday = false;
      this.anniversary = true;
      this.business = false;
      this.reunion = false;
      this.eventsGuests = true;
      this.Guests = true;
    }

    if (selectedValue == "business") {
      this.birthday = false;
      this.anniversary = false;
      this.business = true;
      this.reunion = false;
      this.eventsGuests = true;
      this.Guests = true;
    }

    if (selectedValue == "reunion") {
      this.birthday = false;
      this.anniversary = false;
      this.business = false;
      this.reunion = true;
      this.eventsGuests = true;
      this.Guests = true;
    }
  }

  onPhoneInputChange(event: any): void {
    let inputValue = event.target.value;

    // Allow only numbers
    inputValue = inputValue.replace(/[^0-9]/g, ''); // Remove non-numeric characters

    // Set the value back to the form control
    this.bookingForm.controls['phone'].setValue(inputValue);
  }

  onInputChange(event: any): void {
    const inputValue = event.target.value;
  
    // Trim only leading spaces from the input value
    const trimmedValue = inputValue.replace(/^\s+/, '');  // Removes leading spaces only
  
    // Set the value back to the form control, ensuring no leading spaces
    this.bookingForm.controls['username'].setValue(trimmedValue);
  
  }


  showLunch() {
    this.service.showLunchSlots().subscribe(res => {
      this.lunchSlots = Array.isArray(res) ? res : Object.values(res);
      // this.DinnerSlots = res;
      console.log(this.lunchSlots);


      this.lunchIndoor = this.lunchSlots[0];
      this.lunchOutdoor = this.lunchSlots[1];
      this.lunchPrivate = this.lunchSlots[2].filter((time: any) => time.trim() !== "");;

      // console.log(JSON.stringify(this.lunchSlots));

    })
  }

  showDinner() {
    this.service.showDinnerSlots().subscribe(res => {
      this.DinnerSlots = Array.isArray(res) ? res : Object.values(res);
      // this.DinnerSlots = res;
      console.log(this.DinnerSlots);


      this.dinnerIndoor = this.DinnerSlots[0];
      this.dinnerOutdoor = this.DinnerSlots[1];
      this.dinnerPrivate = this.DinnerSlots[2].filter((time: any) => time.trim() !== "");;

      // console.log(JSON.stringify(this.DinnerSlots));

    })
  }

  selectedTime: string = '';
  isSelected: boolean = false;
  bookingData: any[] = [];

  selectTime(time: string, event: MouseEvent): void {
    event.stopPropagation();
    this.selectedTime = this.selectedTime == time ? '' : time;
    console.log('selected time: ', this.selectedTime);

  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    // Check if the click is outside the container of time slots
    const isClickInside = event.target instanceof HTMLElement && event.target.closest('.selected');
    if (!isClickInside) {
      this.selectedTime = '';  // Deselect if click is outside any time-slot
    }
  }


  submitSelection() {
    if (this.bookingForm.invalid) {
      Swal.fire({
        icon: "error",
        title: "Booking Failed",
        text: "Please fill the required fields.",
        confirmButtonText: "Retry",
      });
    } else {
      const data = {
        "name": this.bookingForm.value.username,
        "email": this.bookingForm.value.email,
        "phone_number": this.bookingForm.value.phone,
        "bookingDate": this.bookingForm.value.date,
        "bookingTime": this.selectedTime,
        "cuisine_type": this.bookingForm.value.cuisines,
        "NumberofGuest": this.bookingForm.value.noOfGuests,
        "foodTiming": this.bookingForm.value.mealTime,
        "tableType": this.bookingForm.value.tableType,
        "indoorTable": this.bookingForm.value.indoorType,
        "event": this.bookingForm.value.eventsType
      }

      console.log(data);

      this.service.insertBooking(data).subscribe(res => {
        this.bookingData = Object(res);
        // this.sendEmail();

      })
      Swal.fire({
        icon: 'success',
        title: 'Booking Successful!',
        text: 'Your booking has been successfully completed. We look forward to serving you!',
        confirmButtonText: "Continue Exploring",
      })
      // this.bookingForm.reset();
      this.sendEmailVerification();
    }
  }

  sendEmailVerification() {
    const bookingDetails = {
      to_name: this.bookingForm.value.username,
      email: this.bookingForm.value.email,
      booking_date: this.bookingForm.value.date,
      no_of_guests: this.bookingForm.value.noOfGuests,
      booking_time: this.selectedTime,
    };

    // EmailJS service call
    emailjs.send('service_foodiefriends', 'template_booking', bookingDetails, 'krXtgDQ_zhz7qq5mM')
      .then(
        (response) => {
          console.log('SUCCESS!', response);
          alert("Success")
        },
        (error) => {
          console.log('FAILED...', error);
          alert("failed")
        }
      );
  }

}
