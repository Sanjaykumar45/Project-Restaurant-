import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';
import Swal from 'sweetalert2';
import { FormBuilder, FormControl, FormGroup, MaxValidator, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [RouterModule, NavbarComponent, CommonModule, ReactiveFormsModule],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent {
  contactform!: FormGroup;
  contactMessage: any[]=[];

  constructor(private fb: FormBuilder, private service: UserServiceService) {
    this.validation();
  }

  // This method is triggered when the input changes.
  onInputChange(event: any, fieldName: string): void {
    const inputValue = event.target.value;

    // Trim leading spaces from the input value.
    const trimmedValue = inputValue.replace(/^\s+/, '');  // Removes leading spaces only

    // Set the value back to the form control, ensuring no leading spaces.
    this.contactform.controls[fieldName].setValue(trimmedValue);

    // If spaces were trimmed, set an error.
    if (trimmedValue !== inputValue) {
      this.contactform.controls[fieldName].setErrors({ spaceDetected: true });
    }
  }

  // Initialize form controls and validation rules.
  validation() {
    this.contactform = this.fb.group({
      username: new FormControl<string | null>(null, [
        Validators.required,
        Validators.pattern('^[^\\s].*$')  // Ensures the username does not start with a space.
      ]),
      phone: new FormControl<string | null>(null, [
        Validators.required,
        Validators.pattern('^\\d{10}$'),
        Validators.maxLength(10)
      ]),
      email: new FormControl<string | null>(null, [
        Validators.required,
        Validators.email,
        Validators.pattern('^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$')
      ]),
      message: new FormControl<string | null>(null, [Validators.required]) // Assuming message is also required.
    });
  }

  // Submit form data.
  onSubmit() {

    if(this.contactform.invalid){
      // Swal.fire({
      //   icon: "error",
      //   title: "Submission Failed",
      //   text: "Please fill out all required fields.",
      //   confirmButtonText: "Retry",
      // });
      this.contactform.markAllAsTouched();
    }
    else{
      const data ={
        "name": this.contactform.value.username,
        "email": this.contactform.value.email,
        "message": this.contactform.value.message
      }
      this.service.insertContact(data).subscribe(res=>{
        this.contactMessage = Object(res);
      })

      Swal.fire({
        icon: 'success',
        title: 'Message Sent Successfully!',
        text: ' We will get back to you soon.',
        confirmButtonText: "Go Back to Contact Form",
      })
      this.contactform.reset();
    }
    
  }
  


}
