import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AbstractControl, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { LoginServiceService } from '../login-service.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2'
import { CommonModule } from '@angular/common';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, HttpClientModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{

  signupData: any[] = []
  loginData: any[] = []
  loginPasswordVisible: boolean = false;
  signupPassword: boolean = false;
  signupConfirmPassword: boolean = false;

  constructor(private service: LoginServiceService, private router: Router) { }

  ngOnInit(): void {
    
  }

  signupForm = new FormGroup({
    userName: new FormControl('', [Validators.required, Validators.pattern('^[^\\s].*$')]),
    email: new FormControl('', [Validators.required, Validators.pattern('^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$')]),
    password: new FormControl('', [Validators.required, Validators.minLength(6), Validators.pattern('^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{6,}$')]),
    confirmPassword: new FormControl('', [Validators.required]),
  })

  loginForm = new FormGroup({
    userInput: new FormControl('', [Validators.required, Validators.pattern('^[^\\s].*$')]),
    password: new FormControl('', [Validators.required, Validators.minLength(6), Validators.pattern('^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{6,}$')]),
    rememberMe: new FormControl (false)
  })


  signupSubmit() {
    if (this.signupForm.invalid) {
      this.signupForm.markAllAsTouched();
    } else {
      const data = {
        "username": this.signupForm.value.userName,
        "email": this.signupForm.value.email,
        "password": this.signupForm.value.password,
        "confirmPassword": this.signupForm.value.confirmPassword
      }

      this.service.signupData(data).subscribe((res: any) => {
        this.signupData = Object(res);
        console.log(JSON.stringify(data));

        if (res.errorMessage === 'The username you entered is already taken. Please choose another one.') {
          Swal.fire({
            icon: "error",
            title: "Username Taken",
            text: res.errorMessage,
          });
        } else if (res.errorMessage === 'The email address is already registered. Please use a different email.') {
          Swal.fire({
            icon: "error",
            title: "Email Taken",
            text: res.errorMessage,
          });
        } else if (res.errorMessage === 'Your passwords do not match. Please ensure both passwords are the same.') {
          Swal.fire({
            icon: 'error',
            title: 'Password Mismatch',
            text: res.errorMessage,
          });
        } else if (res.success) {
          // If the signup was successful, show a success message
          Swal.fire({
            icon: "success",
            title: "Account Created",
            text: res.message,
            confirmButtonText: "Go To Login",
          }).then((result: any) => {
            if (result.isConfirmed) {
              this.signupForm.reset();
              window.location.href = '/login';
              // this.switchtoLogin();
            }
          })
        }
      })
    }
  }

  loginSubmit() {
    // alert(this.loginForm.value.userInput)
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
    } else {
      const data = {
        "username": this.loginForm.value.userInput,
        "password": this.loginForm.value.password,
        "allowCookies": this.loginForm.value.rememberMe
      }

      this.service.loginData(data).subscribe((res: any) => {
        this.loginData = Object(res);
        console.log(JSON.stringify(data));
        console.log("data : ",res);
        
        console.log(res.groupId);
        console.log(res.message);
        

        if(res.groupId === 2){
          Swal.fire({
            title: "Blocked!",
            html: `<strong style="color: red;">${data.username}</strong> has been blocked due to policy violations. You can create a new account.`,
            icon: "error",
            confirmButtonText: "OK"
          })
          this.loginForm.reset();
        }
        else if (res.errMsg === 'The username or email you entered is incorrect. Please check and try again.') {
          Swal.fire({
            icon: 'error',
            title: 'Invalid Username or Email',
            text: res.errMsg,
          });
        } else if (res.errMsg === 'The password you entered is incorrect. Please try again.') {
          Swal.fire({
            icon: 'error',
            title: 'Invalid Password',
            text: res.errMsg,
          });
        } else {
          Swal.fire({
            icon: 'success',
            title: 'Login Successful!',
            text: res.message,
            confirmButtonText: "Explore Now!",
          }).then(() => {
            // Redirect based on groupId
            if (res.groupId === 1) {
              // alert(this.loginForm.value.userInput)
              sessionStorage.setItem('Username', String(this.loginForm.value.userInput));

              this.router.navigate(['/home']); //Redirect to user page
            }
            else if (res.groupId === 0) {
              sessionStorage.setItem('Username', String(this.loginForm.value.userInput));
              this.router.navigate(['/admin']); //Redirect to admin page
            }

          });
        }
      })
    }

  }



  togglePasswordVisibility(): void {
    this.loginPasswordVisible = !this.loginPasswordVisible;
  }

  toggleSignupPass(): void{
    this.signupPassword = !this.signupPassword;
  }

  toggleSignupConfirmPass(): void{
    this.signupConfirmPassword = !this.signupConfirmPassword;
  }
}
